# Production and mastering workflows — Release 3.0

Open one of the complete workflows in ComfyUI:

- [YuE2 / YuE2 Cover / MiniMax Production](../example_workflows/Music_Production_Toolkit.json)

- [Production](../example_workflows/Music_Production_Toolkit.json)
- [AudioEnhance](../example_workflows/Music_Production_AudioEnhance.json)

The examples share
the same independently controlled mastering chain:

`Restoration → POST → Auto-EQ application → Manual EQ → Output rate → Mastering → Export`

The main YuE2/MM3 graph adds an independent, default-on **CLEAN / Artifact
reduction** stage between the optional Refinement output and this mastering
chain. Both Auto-EQ audio inputs receive its output, as does the Mastering
bypass. See [artifact reduction](ARTIFACT_REDUCTION.md).

Auto-EQ analyzes the same post-restoration audio that its application EQ receives.
Its settings feed a dedicated EQ, leaving the second, manual EQ freely editable.
Numbered nodes and a separate green mastering area show the processing order.
In production, artwork occupies the lower lane; output records stay beside the
savers. Color supplements text labels. The production workflow opens on the
mastering chain and that artwork lane; the Audio Enhancement Lab opens on its
source setup.

## Independent controls

In the main YuE2/MM3 workflow, CHOOSE selects YuE2, YuE2 Cover or MiniMax and
centrally switches artwork, refinement, artifact reduction and mastering. YuE2 and its Cover mode
default to refinement off, mastering/artwork on. Central Mastering off skips
the entire area, including sample-rate conversion; the compressor's own bypass
only affects its dynamics/loudness processing. [Cover usage](YUE2.md#cover-an-audio-file).

The production LLM offers **In ComfyUI / Local app / Cloud** modes and generates
fresh text on each queued execution; the old session-ID helper has been removed.
The classic MiniMax workflow's **FLUX.2 cover · ON / OFF** control in **05 · ILLUSTRATE / Cover artwork**
defaults to ON. OFF skips
FLUX preflight downloads and image computation and exports audio without a new
cover. See [LLM_PROVIDERS.md](LLM_PROVIDERS.md) for setup and compatibility details.

| Control | Effect | Starting setting |
|---|---|---|
| CHOOSE `artifact_reduction_enabled` | Independent spectral outlier attenuation before mastering (main workflow) | On; Balanced, maximum 3 dB |
| Auto-EQ `enabled` | Off skips analysis and emits neutral settings | On |
| Manual EQ `bypass` | Disable only manual EQ | False, but empty bands / unity |
| Output rate `target_sample_rate` | Final rate when this stage executes; unaffected by compressor-only bypass, skipped by central Mastering off | 44100; 48000 selectable |
| Master `compressor_enabled` | Compression only; LUFS and limiter stay active | True; ratio 1.5:1 |
| Master `bypass` | Disable all dynamics and loudness processing | False |

The manual EQ can be enabled or bypassed with Auto-EQ either on or off.
No rewiring is required. The linked Auto-EQ application panel shows the automatic
curve; add your own bands in the separate manual EQ panel.

All bundled workflows use Warm - gentle (workflow default): Warm tilt, strength
35%, maximum correction 2 dB, four bands, 40–16000 Hz; no reference is needed. Auto-EQ is enabled by
default in all examples. Warm tilt is a creative option, not a universal spectral
ideal. For reference matching, add a core LoadAudio, connect reference_audio and
choose a Reference preset. Use musically comparable source/reference material.
Personal workflows lacking the optional enabled input retain the analyzer's original
behavior: enabled=True. Disabling analysis does not require a reference.

## Final sample rate and loudness

The former G / Release Prep node is retained solely as **Resample only**. Set
44100 or 48000 there. Keep the final master's target_sample_rate at **keep**.
The dedicated rate stage still executes when only the compressor node's `bypass`
is on, even though that node also bypasses its own resampling. In the main
YuE2/MM3 workflow, CHOOSE → Mastering off skips the entire mastering area,
including the dedicated rate stage, so export keeps the incoming sample rate.
There is no second loudness stage and no resampling after the limiter.

Starting mastering settings are -14 LUFS / -1 dBTP, ratio 1.5:1, soft knee,
20 ms attack and 150 ms release. Makeup and limiter reduction are bounded.
When these limits prevent the loudness target, the report explains the shortfall.
Turning compressor_enabled off retains loudness targeting and peak protection.
Turning master bypass on disables both. EQ alone provides no peak protection.

These settings are a conservative starting point. Listen at matched loudness,
adjust compression to the source and check the final report. Mastering cannot
repair every balance, arrangement or distortion problem in a stereo mix.
The true-peak measurement describes the PCM sent to export, not a subsequently
decoded MP3 or other downstream processing. See [AUDIO_MASTERING.md](AUDIO_MASTERING.md).

## Production records and behavior changes

The production release branch now uses dynamic mastering in place of its old
static-gain release stage, so its audio intentionally differs from the original.
All music generation, LLM, restoration and artwork settings are retained.
The original audio saver still archives the branch before restoration, with its
existing peak-handling policy (not a guaranteed bit-exact archive).

In the classic MiniMax workflow, both decoder alternatives inside its subgraph use
`MiniMaxSafeAudioDecode`. The public `tiled_decode` input, decoder connections
and configured tile size are preserved. Valid audio keeps ComfyUI's original
gain rule. Non-finite decoder output triggers at most one conservative tiled
retry, while invalid sampler latents stop immediately with a specific error.
Reopen the updated example to use this decoder in a previously saved workflow,
or replace both audio decode nodes inside its subgraph manually. The main
YuE2/MM3 workflow creates its checked decoder through `MusicGeneration` expansion. See
[audio export troubleshooting](../TROUBLESHOOTING.md#audio-export-fails-with-a-blank-assertionerror).

Production JSON receives the manual EQ report, Auto-EQ analysis and final
mastering report through the existing optional metadata inputs. The analyzer's
applied=false describes analysis itself; the following EQ applies its settings.
The separate automatic application EQ report is not additionally persisted.
The main workflow also persists the independent artifact reduction report under
`artifact_reduction`, including candidate times, effective settings and bypass.
The resample-only report still records input/output rates. AudioEnhance exports
FLAC without a central production JSON, as before.

The restoration chain ships **off** in both example workflows, and its stages are off
accordingly: PRE low-pass bypassed (`bypass=true`), crossover `Original SRC only`,
POST 19 kHz set. FlashSR is the expensive part - 2.3 GB of weights on first use and
minutes per song - so it is opt-in; switching the chain on (CHOOSE `Refinement`, or
`Refinement enabled` in the Audio Enhancement Lab) means switching its helpers on as
well: B `bypass=false` (PRE 10 kHz is the starting point) and D `mode=FlashSR only`
(`Original + FlashSR air` blends the original low band back in).
Cover render size is 1536 px and embedded cover size is 1024 px. The saved chat model
(`Qwen_Qwen3.5-9B-Q4_K_M.gguf`, 6.2 GiB) with its 37376-token context is a moderate
default; select a smaller catalog model or context when memory is tight. These settings
do not automatically adapt to hardware.

## Remaining architectural considerations

- Production audio savers wait for cover artwork because they embed its path.
  Hiding the cover group does not remove that dependency.
- Visual layout does not serialize GPU branches. Changing execution scheduling
  requires explicit tested dependencies.
- Provenance links remain visible and use existing nodes. No third-party routing
  extension is introduced.
- Export folder names inherited from the source may contain 44; changing the rate
  changes audio, not path names. Update folders if you want names to reflect 48 kHz.

## Rebuild and validation

Edit the three canonical JSON files directly. The former optimizer script now
validates without rewriting files; its historical input graphs have been retired.
Keep personal workflow copies separate when updating the toolkit.

Automated checks cover generation/artwork settings, graph cycles, bidirectional
link indexes, schema compatibility, exact generated content, independent EQ
controls, default output rate, final master-to-saver routing, group containment
and node overlaps. DSP tests cover neutral Auto-EQ output without analysis and
independent manual bypass, alongside the existing loudness, peak and SRC tests.

Manual acceptance in ComfyUI: open each workflow, inspect the mastering group,
try Auto-EQ on/off with manual EQ on/off, then compression off and full bypass.
Render short mono/stereo sources at both 44100 and 48000; inspect the actual saved
rate, final meter report and listen at matched loudness. No missing reference
should be requested while Auto-EQ is disabled. Widget heights may vary with
frontend versions. Automated layout checks do not replace this live check.
