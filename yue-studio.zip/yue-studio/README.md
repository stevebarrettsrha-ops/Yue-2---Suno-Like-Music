# YuE Studio

A local, Suno-style front end for the YuE2 music model. Write a style
description and lyrics, press Create, get a full song with vocals — all on your
own machine, no account, no credits.

It drives ComfyUI in the background. On first launch it installs ComfyUI,
downloads the model files and starts the engine for you.

---

## Running it

**Windows** — double-click `run.bat`
**macOS / Linux** — `./run.sh`

Either way the browser opens at <http://127.0.0.1:7788>.

The setup panel appears on the first run. Pick one of three routes:

| Route | What happens |
|---|---|
| Use an existing ComfyUI | Found installs are listed. Only missing models are downloaded. |
| Install a fresh ComfyUI | Clones ComfyUI into `./ComfyUI`, builds its own venv, installs PyTorch, downloads models. |
| Connect to one I start myself | Set the address and models folder in Settings. Setup only fetches missing models. |

Setup takes a while the first time — mostly PyTorch (about 3 GB) and the model
files. Progress and a live log are shown. It resumes if interrupted: partial
downloads are kept in `.part` files and continued.

### The Engine page

Everything YuE Studio needs is listed there with a state next to it — Python, Git,
ComfyUI, PyTorch, ComfyUI's packages, ffmpeg, the model files, the engine itself.
Anything marked missing has an Install button beside it, and **Install everything
missing** works through them in order. Output streams into the Activity log as it
runs. Nothing needs a terminal.

If PyTorch will not install or your GPU is being ignored, pick a different build
(CUDA 12.8 / 12.4 / 12.1, ROCm, CPU) on the same page and reinstall.

### The Models page

All HuggingFace work happens here:

- **Recommended files** — the three YuE2 files, one button each, with size and
  what they are for.
- **Browse a repo** — type any repo (`Comfy-Org/YuE2` by default), see its files
  with sizes, and download the ones you want. Each file's target folder is worked
  out from its path and can be overridden.
- **Token and mirror** — paste an access token for gated repos, or point at a
  mirror if huggingface.co is slow. The token is stored locally and only ever
  shown as its last four characters.
- **Downloads** — live progress, speed, time left, and a Stop button. Stopping
  keeps the partial file, so starting again resumes.
- **On this machine** — every model file found, with its size, and a Delete
  button. Unfinished downloads are marked.

### Requirements

- Python 3.10 or newer
- Git (only for the managed-install route)
- ComfyUI **v0.35.0 or newer** — YuE2 nodes are built in from that version.
  v0.35.1+ is recommended on AMD cards.
- An NVIDIA GPU with 8 GB+ VRAM for reasonable speed. CPU works but is slow.

### Model files

Downloaded from `Comfy-Org/YuE2` on HuggingFace into your ComfyUI models folder:

```
models/checkpoints/yue2_3b_int8_convrot.safetensors     3.96 GB   required
models/audio_encoders/sheetsage2_bf16.safetensors       1.39 GB   cover mode
models/checkpoints/yue2_3b_bf16.safetensors             7.80 GB   optional, higher quality
```

---

## Using it

**Styles** carries all the musical instruction: genre, vocal type, language,
tempo, instruments, mood. Example:

> English, roots reggae, warm male vocal, 74 BPM, offbeat guitar skank, deep
> bass, organ bubble, sunlit and steady

**Lyrics** holds only words that get sung, with section tags:

```
[Verse]
Morning light across the window
City waking down below

[Chorus]
Run with me into the sunlight
```

Leave lyrics empty, or switch Instrumental on, for a vocal-free track.

**More options**

- *Melody plan* — `full` writes melody and chords before rendering audio
  (best general setting), `melody` plans the tune only and lets the backing
  roam, `off` goes straight from text to audio.
- *Max length* — a ceiling, not a target. Songs often end earlier.
- *Steps / sampler / scheduler* — the diffusion pass. 32 steps with `dpm_2` and
  `sgm_uniform` matches the reference workflow.
- *Seed* — leave blank for random, or fix it to re-roll a song with one change.
- *Tiled decode* — leave on unless you have plenty of VRAM; off is faster.

**Cover from audio** uploads a reference song, transcribes its melody to ABC
notation with SheetSage2, then re-sings it with your style and lyrics. The
audio itself is never fed to the model — only the melody. Covers work best when
new lines match the original phrasing and syllable count.

`Ctrl` + `Enter` creates from anywhere in the page.

Finished songs land in the workspace on the right and are copied into
`data/tracks/`, so they survive ComfyUI clearing its output folder.

---

## Notes on your uploads

- `yue2_full__1_.json` is kept at `assets/yue2_full_reference.json`. The app
  builds the same graph, so you can open that file in ComfyUI any time to check
  the app's output against the original workflow.
- The ComfyUI Desktop installer you uploaded works as the "existing install"
  route — install it, start it once, then point YuE Studio at it in Settings
  (Desktop usually serves on `http://127.0.0.1:8000`).
- `github.com/multimodal-art-projection/YuE` is the model authors' own
  repository and a separate inference stack. Your workflow uses ComfyUI's
  **native** YuE2 nodes instead, which is why nothing is cloned from that repo.

---

## Troubleshooting

**"This ComfyUI has no 'YuE2GenerateMusic' node"**
ComfyUI is older than v0.35.0. Update it (`git pull` in the ComfyUI folder,
then reinstall requirements), or use the managed install route.

**Setup stops on PyTorch**
The wheel index is guessed from your hardware. Set it by hand in Settings —
`https://download.pytorch.org/whl/cu128` for recent NVIDIA drivers,
`https://download.pytorch.org/whl/cu121` for older ones,
`https://download.pytorch.org/whl/cpu` for no GPU.

**Downloads keep failing**
They resume, so pressing Start setup again picks up where it stopped. You can
also download the files by hand from HuggingFace and drop them in the folders
listed above; setup then skips them.

**Out of memory during generation**
Lower Max length, keep Tiled decode on, and use the int8 checkpoint rather than
bf16.

**Generation never finishes**
The first run of any model loads slowly. Check the ComfyUI console output shown
at the bottom of the setup panel, and the ComfyUI window itself.

---

## Layout

```
server.py      Flask API — setup, jobs, library, audio streaming
bootstrap.py   Python/ComfyUI discovery, installs, model downloads, process control
comfy.py       Builds the YuE2 graph from ComfyUI's /object_info schema, queues it
web/index.html The interface — one file, no build step
data/          config.json, library.json, tracks/
```

Port: set `YUE_STUDIO_PORT` to move off 7788. Set `YUE_STUDIO_NO_BROWSER=1` to
stop it opening a browser tab.
